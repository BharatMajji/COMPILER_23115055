#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression (e.g., SI amount = 1000, 5, 2; or CI final = 1000, 5, 2;):\n";
    yyparse();
    return 0;
}
