# Simple Interest & Compound Interest Parser

This project implements a basic parser using Flex (Lex) and Bison (Yacc) to calculate **Simple Interest (SI)** and **Compound Interest (CI)** from expressions entered by the user.

## 🧩 Project Structure

```
.
├── main.cpp        # Main C++ driver file
├── lexer.l         # Flex (Lex) lexical analyzer
├── parser.y        # Bison (Yacc) parser
├── Makefile        # Build instructions
```

## 📥 Requirements

- `g++` (C++ compiler)
- `flex`
- `bison`

Install them on Ubuntu/Debian:
```bash
sudo apt update
sudo apt install build-essential flex bison
```

## ⚙️ Build Instructions

To compile the project, simply run:

```bash
make
```

This will:
- Generate `lex.yy.c` using `flex`
- Generate `parser.tab.c` and `parser.tab.h` using `bison`
- Compile everything into an executable (e.g., `interest_parser`)

## 🚀 Usage

Run the program:

```bash
./interest_parser
```

Then input expressions like:

```
SI amount = 1000, 5, 2;
CI final = 1000, 5, 2;
```

The program will parse the input and evaluate interest expressions accordingly.

## 🧮 Interest Formulae

- **Simple Interest (SI):**  
  \( SI = rac{P 	imes R 	imes T}{100} \)

- **Compound Interest (CI):**  
  \( CI = A - P \) where  
  \( A = P 	imes \left(1 + rac{R}{100}ight)^T \)

## 🧹 Clean

To clean all generated files:

```bash
make clean
```

## 📄 License

This project is licensed under the MIT License.

---

Happy calculating! 💰
